#include "Filter.h"
#include "Filter_PVT.h"


/*******************************************************************************
* ChannelA filter coefficients.
* Filter Type is FIR
*******************************************************************************/

/* Renamed array for backward compatibility.
*  Should not be used in new designs.
*/
#define ChannelAFirCoefficients Filter_ChannelAFirCoefficients

/* Number of FIR filter taps are: 2 */

const uint8 CYCODE Filter_ChannelAFirCoefficients[Filter_FIR_A_SIZE] = 
{
 0x92u, 0xE7u, 0x43u, 0x00u, /* Tap(0), 0.530504465103149 */

 0x92u, 0xE7u, 0x43u, 0x00u, /* Tap(1), 0.530504465103149 */
};

