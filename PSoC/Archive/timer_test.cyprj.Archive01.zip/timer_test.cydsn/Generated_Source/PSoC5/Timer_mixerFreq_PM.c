/*******************************************************************************
* File Name: Timer_mixerFreq_PM.c
* Version 2.80
*
*  Description:
*     This file provides the power management source code to API for the
*     Timer.
*
*   Note:
*     None
*
*******************************************************************************
* Copyright 2008-2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#include "Timer_mixerFreq.h"

static Timer_mixerFreq_backupStruct Timer_mixerFreq_backup;


/*******************************************************************************
* Function Name: Timer_mixerFreq_SaveConfig
********************************************************************************
*
* Summary:
*     Save the current user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_mixerFreq_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void Timer_mixerFreq_SaveConfig(void) 
{
    #if (!Timer_mixerFreq_UsingFixedFunction)
        Timer_mixerFreq_backup.TimerUdb = Timer_mixerFreq_ReadCounter();
        Timer_mixerFreq_backup.InterruptMaskValue = Timer_mixerFreq_STATUS_MASK;
        #if (Timer_mixerFreq_UsingHWCaptureCounter)
            Timer_mixerFreq_backup.TimerCaptureCounter = Timer_mixerFreq_ReadCaptureCount();
        #endif /* Back Up capture counter register  */

        #if(!Timer_mixerFreq_UDB_CONTROL_REG_REMOVED)
            Timer_mixerFreq_backup.TimerControlRegister = Timer_mixerFreq_ReadControlRegister();
        #endif /* Backup the enable state of the Timer component */
    #endif /* Backup non retention registers in UDB implementation. All fixed function registers are retention */
}


/*******************************************************************************
* Function Name: Timer_mixerFreq_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_mixerFreq_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void Timer_mixerFreq_RestoreConfig(void) 
{   
    #if (!Timer_mixerFreq_UsingFixedFunction)

        Timer_mixerFreq_WriteCounter(Timer_mixerFreq_backup.TimerUdb);
        Timer_mixerFreq_STATUS_MASK =Timer_mixerFreq_backup.InterruptMaskValue;
        #if (Timer_mixerFreq_UsingHWCaptureCounter)
            Timer_mixerFreq_SetCaptureCount(Timer_mixerFreq_backup.TimerCaptureCounter);
        #endif /* Restore Capture counter register*/

        #if(!Timer_mixerFreq_UDB_CONTROL_REG_REMOVED)
            Timer_mixerFreq_WriteControlRegister(Timer_mixerFreq_backup.TimerControlRegister);
        #endif /* Restore the enable state of the Timer component */
    #endif /* Restore non retention registers in the UDB implementation only */
}


/*******************************************************************************
* Function Name: Timer_mixerFreq_Sleep
********************************************************************************
*
* Summary:
*     Stop and Save the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_mixerFreq_backup.TimerEnableState:  Is modified depending on the
*  enable state of the block before entering sleep mode.
*
*******************************************************************************/
void Timer_mixerFreq_Sleep(void) 
{
    #if(!Timer_mixerFreq_UDB_CONTROL_REG_REMOVED)
        /* Save Counter's enable state */
        if(Timer_mixerFreq_CTRL_ENABLE == (Timer_mixerFreq_CONTROL & Timer_mixerFreq_CTRL_ENABLE))
        {
            /* Timer is enabled */
            Timer_mixerFreq_backup.TimerEnableState = 1u;
        }
        else
        {
            /* Timer is disabled */
            Timer_mixerFreq_backup.TimerEnableState = 0u;
        }
    #endif /* Back up enable state from the Timer control register */
    Timer_mixerFreq_Stop();
    Timer_mixerFreq_SaveConfig();
}


/*******************************************************************************
* Function Name: Timer_mixerFreq_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_mixerFreq_backup.enableState:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void Timer_mixerFreq_Wakeup(void) 
{
    Timer_mixerFreq_RestoreConfig();
    #if(!Timer_mixerFreq_UDB_CONTROL_REG_REMOVED)
        if(Timer_mixerFreq_backup.TimerEnableState == 1u)
        {     /* Enable Timer's operation */
                Timer_mixerFreq_Enable();
        } /* Do nothing if Timer was disabled before */
    #endif /* Remove this code section if Control register is removed */
}


/* [] END OF FILE */
